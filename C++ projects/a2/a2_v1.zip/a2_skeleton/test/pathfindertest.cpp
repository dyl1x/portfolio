#include "gtest/gtest.h"
#include <iostream>

#include <vector>

// Student defined libraries, for instance
#include "pathfinder.h"

#include "tf.h"
#include "types.h"


//==================== UNIT TEST START ====================//

TEST(PathFinder, LocalToGlobal)
{
    std::vector<geometry_msgs::RangeBearingStamped> rbsBogie;
    geometry_msgs::Pose loc;
    loc.position.x = 100;
    loc.position.y = 0;
    loc.orientation = tf::yawToQuaternion(0);
    geometry_msgs::RangeBearingStamped b1;
    b1.range = 3245.12;
    b1.bearing = 1.78646;
    rbsBogie.push_back(b1);

    geometry_msgs::RangeBearingStamped b2;
    b2.range = 3977.98;
    b2.bearing = 5.46434;
    rbsBogie.push_back(b2);

    PathFinder path(rbsBogie, loc );
}

//TEST(PoseTest, GlobalToLocal)
//{



//}


int main(int argc, char **argv)
{
  ::testing::InitGoogleTest(&argc, argv);

  return RUN_ALL_TESTS();
}
