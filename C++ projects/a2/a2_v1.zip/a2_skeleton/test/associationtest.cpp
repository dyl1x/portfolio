#include "gtest/gtest.h"
#include <iostream>
#include <vector>

// Student defined libraries, for instance
//#include "flightplanner.h"

#include "types.h"


//==================== UNIT TEST START ====================//


TEST(AssociationTest, RangeBearingToBogie)
{



}

TEST(AssociationTest, RangeVelocityToBogie)
{



}


int main(int argc, char **argv)
{
  ::testing::InitGoogleTest(&argc, argv);

  return RUN_ALL_TESTS();
}
