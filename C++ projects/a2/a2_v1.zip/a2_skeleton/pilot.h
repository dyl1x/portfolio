#ifndef PILOT_H
#define PILOT_H

/*!
 * \brief The Pilot class
 * \details The Pilot class controls the the friendly arcraft and manages the data to and from the aircraft and
 * base station. Uses the \ref PathFinder class for path planning. Also uses \ref types , \ref simulator ,
 * \ref timer , \ref tf (type transforms).
 *  \author    Chamath Edirisinhege
 *  \version   1.0
 *  \date      2021-09-23
 *  \bug       none reported as of 2021-09-023
 */

#include <thread>
#include <atomic>
#include <vector>
#include <mutex>
#include <condition_variable>
#include "simulator.h"
#include "types.h"
#include "timer.h"
#include "tf.h"
#include "pathfinder.h"


class Pilot
{
public:

    /*!
     * \brief Pilot constructor
     * \details Creates an object that controls the motion of the friendly aircraft
     * \param shared pointer to the simulator
     */
    Pilot(std::shared_ptr<simulator::Simulator> &sim);

    /*! @brief Pilot destructor.
     *
     *  Tears down the Pilot
     */
    ~Pilot();

    /*!
     * \brief Friendly pilot will start to fly
     * \details Starts the simulation by spawning bogies and initiates 2 more threads for piloting and
     * getting information form the simulation.
     */
    void start();


private:

    /*!
     * \brief printData
     * \details console output information obtained from the simulator. Used for testing.
     */
    //void printData();

    /*!
     * \brief pilots the friendly aircraft
     * \details feeds the simulation with the linear and angular velocities in a timley manner to satisfy the
     * watchdog timer
     */
     void control();

    /*!
     * \brief Gets infomation
     * \details Querries the simulator to obtain information about the bogies and the friendly and updates
     * the pilot.
     */
    void getInfomation();

    /*!
     * \brief drive
     */
    void drive();

    /*!
     * \brief purePursuit
     * \param goal
     */
    void purePursuit(geometry_msgs::Point goal);

    /*!
     * \brief checkBounds
     * \return
     */
    bool checkBounds();

    void testPoses (std::vector<geometry_msgs::Point> goals);

private:
    std::atomic<bool> running_; /*!<indicates that the control loop should still be running. */
    std::atomic<bool> updates_; /*!<indicates that the new data is available */
    std::atomic<bool> directions_;
    std::vector<std::thread> threads_; /*!<contains all the threads created by the object */
    std::shared_ptr<simulator::Simulator> sim_; /*!<pointer to the simulator */
//control variables
    double controlLV_;
    double controlAV_;
//information
    std::vector<RangeVelocityStamped> rvsFromBase_; /*!<range and velocity of bogies from base */
    std::vector<RangeBearingStamped> rbsFromFriendly_; /*!<range and bearing of bogies from friendly */
    std::mutex mu_;
    std::condition_variable cond_;
    std::mutex mu2;
    std::condition_variable cond2;

};
#endif // PILOT_H
