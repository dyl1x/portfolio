#ifndef PATHFINDER_H
#define PATHFINDER_H

/*!
 *  \brief The PathFinder class does the path planning
 *  \details This class contains all the graphs and graph searching algorythms that will be used to find the optimal paths
 * and visiting orders.
 *  \author    Chamath Edirisinhege
 *  \version   1.0
 *  \date      2021-09-23
 *  \bug       none reported as of 2021-09-023
 */
#include <iostream>
#include <thread>
#include <vector>
#include <limits>
#include <algorithm>
#include <cmath>
#include "types.h"
#include "tf.h"
#include "tf2.h"

typedef std::vector<std::vector<double> > matrix;

class PathFinder
{
public:
    /*!
     * \brief Pathfinder constructor
     * \param rbsBogie - range bearing stamped vector with bogie data
     * \param loc - pose of frindly
     * \param maxV - max velocity
     * \param maxG - max G force
     * \param minV - min velocity
     * \details Creates an object that does path planning
     */
    PathFinder(double maxV, double maxG, double minV);

    /*! @brief PathFinder destructor.
     *
     *  Tears down the PathFinder
     */
    ~PathFinder();

    /*!
     * \brief Pathfinder updater
     * \param rbsBogie - range bearing stamped vector with bogie data
     * \param loc - pose of frindly
     * \details updates the input variables of the class, this is to prevent from having to make a new
     * object for calculation. Also resets calculation variable in preperation for a new calculation
     * cycle
     */
    void update(std::vector<geometry_msgs::RangeBearingStamped> rbsBogie, geometry_msgs::Pose loc);

    /*!
     * \brief gets the optimal path
     * \details Uses TSP algorithm to calculate the "best" order to navigate the points, visiting each
     * point at least once. Brute force mehtod from geeks for geeks. Modified to use vectors and doesnt add
     * the return distance.
     * \link https://www.geeksforgeeks.org/traveling-salesman-problem-tsp-implementation/
     */
    std::vector<geometry_msgs::Point> getPath();

    /*!
     * \brief adds nodes
     * \details adds nodes to the matrix, doesnt update the path.
     */
    void addNodes();


private:

    /*!
     * \brief gets the edge weight
     * \param range from point a to b
     * \param bearing of point b from a
     * \details uses the turn angle and the estimated travelling distance to calculate a
     * weight, which is the total time taken to reach the given coordinates from current position
     */
    double getWeight(double range, double bearing);

    /*!
     * \brief setGlobalCoordinates
     * \details fills a container with the positions of the bogies in the global coordinate frame
     * the position of the friendly is added as the first element in the container, always.
     */
    void setGlobalCoordinates();


private:
    matrix nodeDist_;
    std::vector<geometry_msgs::Point> nodes_; /*!<node positions in the global frame*/
    std::vector<geometry_msgs::RangeBearingStamped> rbsBogie_;
    geometry_msgs::Pose loc_; /*!<Friendly position */
//constants from the simulator
    double maxV_ = 1000; /*!<Max linear velocity */
    double maxG_ = 6; /*!<Max G force */
    double minV_ = 50; /*!<Min linear velocity */

};

#endif // PATHFINDER_H
