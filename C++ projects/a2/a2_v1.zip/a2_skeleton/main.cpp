/*! @file
 *
 *  @brief Main entry point for assignment 2.
 *
 *  TODO: Add information here
 *
 *  @author Chamath Edirisinhege - 12977866
 *  @date 23 Sept 2021
*/

#include <iostream>
#include "simulator.h"
#include "pilot.h"

using simulator::GameMode;


int main(int argc, char *argv[])
{

   GameMode game_mode = GameMode::BASIC;
   //If code is started with --advanced, it will run in advanced mode
   std::cout << "Run with: " << argv[0] << " --advanced to run in advanced mode" << std::endl;
   if(argc>1){
       if(strcmp (argv[1],"-advanced")){
           std::cout << "Advanced Mode Activated" << std::endl;
           game_mode = GameMode::ADVANCED;
       }
   }
   std::shared_ptr<simulator::Simulator> sim(new simulator::Simulator(true,game_mode));

   switch (game_mode) {
   case GameMode::BASIC: {//do basic mode stuff
       Pilot pilot(sim);
       pilot.start();
       break;
   }
   case GameMode::ADVANCED: {//do advanced mode stuff
       Pilot pilot(sim);
       pilot.start();
       break;
   }
   }


  return 0;
}
