#include "pilot.h"

Pilot::Pilot(std::shared_ptr<simulator::Simulator> &sim):
    controlLV_ (50.1),
    controlAV_ (0.0)
{
    sim_ = sim;
    running_ = true;
    updates_ = false;
    directions_ = false;
}

Pilot::~Pilot()
{
    //running_ = false;
    for (auto &t : threads_) {
        t.join();
    }
}

void Pilot::control()
{
    double lv = 50;
    double av = 0.0;
    while (running_) {


        if (directions_)
        {
            std::unique_lock<std::mutex> locker2 (mu2);
            cond2.wait(locker2, [&](){return directions_ == true;});
            lv = controlLV_;
            av = controlAV_;           
            directions_ = false;
            locker2.unlock();
            cond2.notify_one();
            std::cout << "dir updated" << std::endl;
        }
        sim_->controlFriendly(lv,av);
        std::this_thread::sleep_for(std::chrono::milliseconds(26));
    }
}

void Pilot::getInfomation()
{
    while (running_) {

        for (unsigned int c =0; c <10; c++ )
        {
            std::unique_lock<std::mutex> locker (mu_);
            rbsFromFriendly_ = sim_->rangeBearingToBogiesFromFriendly();
            updates_ = true;
            cond_.notify_one();
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        rvsFromBase_ = sim_->rangeVelocityToBogiesFromBase();
    }
}

void Pilot::drive()
{
    std::vector<geometry_msgs::Point> goals;
    PathFinder path1(sim_->V_MAX,sim_->G_MAX,sim_->V_TERM);
    Timer t1;
    while (running_) {

        {
            std::unique_lock<std::mutex> locker (mu_);
            cond_.wait(locker, [&]() {return updates_ == true;});
            path1.update(rbsFromFriendly_,sim_->getFriendlyPose());
            updates_ = false;
            cond_.notify_one();
            std::cout << "updates" << std::endl;
        }
        goals = path1.getPath();
        purePursuit(goals.at(0));

        if (t1.elapsed() > 2000)
        {
            t1.reset();
            testPoses(goals);
        }
    }
}

void Pilot::start()
{
    running_ = true;
    threads_.push_back(sim_->spawn());
    threads_.push_back(std::thread(&Pilot::getInfomation, this));
    threads_.push_back(std::thread(&Pilot::drive, this));
    threads_.push_back(std::thread(&Pilot::control, this));
}

void Pilot::purePursuit(geometry_msgs::Point goal)
{
    geometry_msgs::Point loc = sim_->getFriendlyPose().position;
    double fOrient = tf::quaternionToYaw(sim_->getFriendlyPose().orientation);
    fOrient = tf2::normalise180Angle(fOrient);

    double thetaError = (atan2((goal.y-loc.y),(goal.x-loc.x))) - fOrient;
    thetaError = tf2::normalise180Angle(thetaError);
    thetaError *= 0.6; //gain
    std::cout << thetaError << std::endl;


    {
        std::unique_lock<std::mutex> locker2 (mu2);
        if (checkBounds())
        {
            std::cout << "bounds" << std::endl;
            controlAV_ = 1.177;
            controlLV_ = ((sim_->G_MAX)*9.81)/fabs(controlAV_);
        }
        else
        {
            if (fabs(thetaError) < 0.05886)
            {
                controlAV_ = thetaError;
                controlLV_ = sim_->V_MAX;
                std::cout << "1" << std::endl;
            }
            else if (fabs(thetaError) > 1.1772) {
                controlAV_ = std::copysign(1.177,thetaError);
                controlLV_ = ((sim_->G_MAX) *9.81)/fabs(controlAV_);
                std::cout << "2" << std::endl;
            }
            else {
                controlAV_ = thetaError;
                controlLV_ = ((sim_->G_MAX)*9.81)/controlAV_;
                std::cout << "3" << std::endl;
            }
        }
        directions_ = true;
        cond2.notify_one();
    }

}

bool Pilot::checkBounds()
{

    double edge = (sim_->AIRSPACE_SIZE/2)-150;
    geometry_msgs::Point loc = sim_->getFriendlyPose().position;
    if ( edge < fabs(loc.x) || edge < fabs(loc.y))
    {
        return true;
    }
    return false;
}

void Pilot::testPoses(std::vector<geometry_msgs::Point> goals)
{
    std::vector<geometry_msgs::Pose> poses;
    for (auto g : goals) {
        geometry_msgs::Pose p;
        p.orientation = tf::yawToQuaternion(0);
        p.position = g;
        poses.push_back(p);
    }
    sim_->testPose(poses);
}


