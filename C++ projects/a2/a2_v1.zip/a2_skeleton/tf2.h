/*! @file
 *
 *  @brief Collection of transforms between structures defined under types namespace
 *
 *
 *  @author Chamath Edirisinhege
 *  @date 02-10-2021
*/
#ifndef TF2_H
#define TF2_H
#include <cmath>
#include "types.h"
#include "tf.h"

using geometry_msgs::Pose;
using geometry_msgs::Point;
using geometry_msgs::RangeBearingStamped;

namespace tf2 {

/*!
 * \brief local2Global
 * \param rangeBearing - spherical coordinates w.r.t. local frame
 * \param localFrame - pose of the local frame
 * \return Point (x,y) in the global frame, of the spherical coordinates (range, beaering)
 */
Point local2Global(RangeBearingStamped rangeBearing, Pose localFrame);

/*!
 * \brief global2local
 * \param bogie - Rectangular coordinates of a point in the global frame
 * \param localFrame - pose of the local frame
 * \return spherical coordinates of the point in the local frame.
 */
RangeBearingStamped global2local(Point bogie, Pose localFrame);

/*!
 * \brief sperical2rectangular
 * \param range
 * \param bearing
 * \return Point (x,y) rectangular coordinates
 */
Point sperical2rectangular(double range, double bearing);

/*!
 * \brief rectangular2sperical
 * \param x
 * \param y
 * \return Point (range,bearing, 0) spherical coordinates.
 */
RangeBearingStamped rectangular2sperical(double x, double y);

/*!
 * \brief getRange
 * \param a - point 1
 * \param b - point 2
 * \return distance from a to b.
 */
double getRange(geometry_msgs::Point a, geometry_msgs::Point b);

/*!
 * \brief getBearing
 * \param a - point 1
 * \param b - point 2
 * \return bearin of point b from point a, starting from x axis of point a.
 * returns both positive and negative angles. CCW turn is positive.
 */
double getBearing(geometry_msgs::Point a, geometry_msgs::Point b);

/*!
 * \brief normaliseAngle
 * \param theta
 * \return theta if measured from the x-axis, anticlockwise
 */
double normaliseAngle(double theta);

/*!
 * \brief normalise180Angle
 * \param theta
 * \return
 */
double normalise180Angle(double theta);

/*!
 * \brief reversalize
 * \param angle
 * \return undo what \ref normalizeAngle does
 */
double reversalize(double angle);
}
#endif // TF2_H
