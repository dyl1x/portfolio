#include "pathfinder.h"

PathFinder::PathFinder(double maxV, double maxG, double minV):

    maxV_(maxV),
    maxG_(maxG),
    minV_(minV)
{

}

PathFinder::~PathFinder()
{

}

void PathFinder::update(std::vector<geometry_msgs::RangeBearingStamped> rbsBogie, geometry_msgs::Pose loc)
{
    rbsBogie_ = rbsBogie;
    loc_ = loc;

    nodeDist_.clear();
    nodes_.clear();
}

double PathFinder::getWeight(double range, double bearing)
{
    double maxOmega = (maxG_*9.81)/minV_;
    bearing = std::fabs(bearing);
    double w = (bearing/maxOmega) + (range/maxV_);
    return w;
}

std::vector<geometry_msgs::Point> PathFinder::getPath() //tsp stuff
{
    addNodes();
    std::vector<unsigned int> vertex;
    std::vector<unsigned int> out;
    for (unsigned int i = 1; i < nodes_.size(); i++ )
    {
        vertex.push_back(i);
    }

    double min_path_w = std::numeric_limits<double>::max();

    do {
        double cost = 0;

        unsigned int k=0;
        //unsigned int s=0; //used for return edge

        for (unsigned int i = 0; i < vertex.size(); i++) {
            cost += nodeDist_.at(k).at(vertex.at(i));
            k = vertex.at(i);
        }

        //cost += matrix.at(k).at(s); //we dont need to return to start

        min_path_w = std::min(min_path_w,cost);

        if((cost - min_path_w) < std::numeric_limits<double>::epsilon())
        {
            out = vertex;
        }

    } while (std::next_permutation(vertex.begin(),vertex.end()));

    //out.insert(out.begin(),0);

    std::vector<geometry_msgs::Point> goals;

    for (unsigned int i=0;i<out.size();i++) {
        goals.push_back(nodes_.at(out.at(i)));
    }

    return goals;
}

void PathFinder::setGlobalCoordinates()
{

    double fx = loc_.position.x;
    double fy = loc_.position.y;
    geometry_msgs::Point f {fx,fy,0};
    nodes_.push_back(f);

    for (unsigned int i=0; i<rbsBogie_.size(); i++) {
        geometry_msgs::Point point = tf2::local2Global(rbsBogie_.at(i),loc_);
        nodes_.push_back(point);
    }
    //now all the nodes are in the vector, in global coordinate frame.
}


void PathFinder::addNodes()
{
    setGlobalCoordinates();
    for (unsigned int i = 0; i < nodes_.size(); i++) {
        std::vector<double> row;
        for (unsigned int j = 0; j < nodes_.size(); j++) {
            row.push_back(0);
        }
        nodeDist_.push_back(row);
    } // matrix is now the correct size nbogie+1, square

    //now we put the weights in

    for (unsigned int c = 0; c < nodeDist_.size(); c++) {

        for (unsigned int r = 0; r < nodeDist_.at(c).size(); r++) {
            nodeDist_.at(c).at(r) = getWeight(tf2::getRange(nodes_.at(c), nodes_.at(r)),
                                              tf2::getBearing(nodes_.at(c), nodes_.at(r)));
        }
    }

}
