var indexSectionsWithContent =
{
  0: "abcdglmnprstu~",
  1: "abp",
  2: "abmpt",
  3: "abcdgpstu~",
  4: "bcdlmnrstu",
  5: "ab"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};

