var searchData=
[
  ['point',['POINT',['../namespaceranger.html#ab04465c229cc50595ffe40a891a3b135a6cd3b981ee1a6dc6afc81a8052d366f3',1,'ranger']]]
];
