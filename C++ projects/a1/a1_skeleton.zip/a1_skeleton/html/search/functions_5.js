var searchData=
[
  ['ranger',['Ranger',['../classRanger.html#ad87e3ddf656eae8f77c88297a313c8a1',1,'Ranger']]],
  ['rangerfusion',['RangerFusion',['../classRangerFusion.html#ae06d13fa52742f42e138b386e5022168',1,'RangerFusion']]]
];
