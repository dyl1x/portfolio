var searchData=
[
  ['angresolution_5f',['angResolution_',['../classRanger.html#abf27486783526e849e3752036ea16ba7',1,'Ranger']]]
];
