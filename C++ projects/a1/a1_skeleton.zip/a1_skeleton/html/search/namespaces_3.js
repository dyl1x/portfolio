var searchData=
[
  ['ranger',['ranger',['../namespaceranger.html',1,'']]]
];
