var searchData=
[
  ['setangularresolution',['setAngularResolution',['../classLaser.html#a518ac84d4631b1550330d664e161ca0a',1,'Laser::setAngularResolution()'],['../classRanger.html#a3dc62dcba54eefbd7a0f08cbf97d87dc',1,'Ranger::setAngularResolution()'],['../classRangerInterface.html#aecffc9bbb58379da741c18326b9e41db',1,'RangerInterface::setAngularResolution()']]],
  ['setcells',['setCells',['../classRangerFusion.html#a9b69869bd1e3bca155bcecbad5ea463b',1,'RangerFusion::setCells()'],['../classRangerFusionInterface.html#ab8fdee0050521767d33179a63da91e4f',1,'RangerFusionInterface::setCells()']]],
  ['setcentre',['setCentre',['../classCell.html#a882f75366d9cf6477d1fd7f9dd54519b',1,'Cell']]],
  ['setfieldofview',['setFieldOfView',['../classLaser.html#a5f140784aae7e82c2aa0f690548d6ebb',1,'Laser::setFieldOfView()'],['../classRanger.html#afb5d392ca450bcce295e61c121d09157',1,'Ranger::setFieldOfView()'],['../classRangerInterface.html#a70357ca516198af45e2d503ef6af8f9f',1,'RangerInterface::setFieldOfView()'],['../classSonar.html#a74d551d0ad61861ccf903f2535d799f0',1,'Sonar::setFieldOfView()']]],
  ['setradius',['setRadius',['../classCircle.html#a7a1b334833a9f468498c804264553f41',1,'Circle']]],
  ['setscanarea',['setScanArea',['../classSonar.html#a8234f001a2348746880010b742ccecd2',1,'Sonar']]],
  ['setsensorpose',['setSensorPose',['../classRanger.html#aa55ad45d83b8c095a495677ac8873f2b',1,'Ranger::setSensorPose()'],['../classRangerInterface.html#a452301937b5ace7ded943d8aa76a061f',1,'RangerInterface::setSensorPose()']]],
  ['setside',['setSide',['../classCell.html#a9c4fd400ffbf61fe18073f3b244614ab',1,'Cell']]],
  ['setstate',['setState',['../classCell.html#adeb7a033171fa07557e756f3fcc4717d',1,'Cell']]],
  ['sonar',['Sonar',['../classSonar.html#a71ef009d138f1e372fc35ca0cb6e85e2',1,'Sonar::Sonar()'],['../classSonar.html#a810fa5faf9ddee8ffd09c77556efda0c',1,'Sonar::Sonar(ranger::SensorPose pose)'],['../classSonar.html#ac29c8ae54d18c0ab4effbaa6fc389df4',1,'Sonar::Sonar(double maxr, double minr, unsigned int fov, ranger::SensorPose pose, sonar::description model)']]]
];
