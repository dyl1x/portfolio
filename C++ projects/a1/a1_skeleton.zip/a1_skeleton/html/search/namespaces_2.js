var searchData=
[
  ['laser',['laser',['../namespacelaser.html',1,'']]]
];
