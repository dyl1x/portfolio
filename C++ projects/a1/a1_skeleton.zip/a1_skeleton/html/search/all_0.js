var searchData=
[
  ['angresolution_5f',['angResolution_',['../classRanger.html#abf27486783526e849e3752036ea16ba7',1,'Ranger']]],
  ['area',['area',['../classCell.html#ad4fa31d97490fac2a1d11f3afaea4e67',1,'Cell']]],
  ['assignment_201_3a_20utilising_20abstraction_20for_20a_20range_20of_20sensor_20classes',['Assignment 1: Utilising Abstraction for a Range of Sensor Classes',['../index.html',1,'']]]
];
