var searchData=
[
  ['assignment_201_3a_20utilising_20abstraction_20for_20a_20range_20of_20sensor_20classes',['Assignment 1: Utilising Abstraction for a Range of Sensor Classes',['../index.html',1,'']]]
];
